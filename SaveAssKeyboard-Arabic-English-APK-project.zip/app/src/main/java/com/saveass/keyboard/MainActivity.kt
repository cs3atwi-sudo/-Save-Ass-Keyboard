package com.saveass.keyboard

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        box.addView(TextView(this).apply {
            text = "Save Ass Keyboard\n\nA consent-based keyboard with local text history.\n\nPassword and sensitive fields are never recorded. Text stays on this device."
            textSize = 18f
        })
        box.addView(Button(this).apply {
            text = "1. Enable keyboard"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        box.addView(Button(this).apply {
            text = "2. Choose Save Ass Keyboard"
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showInputMethodPicker()
            }
        })
        box.addView(Button(this).apply {
            text = "Open local text log"
            setOnClickListener {
                val f = getExternalFilesDir(null)?.resolve("save ass.txt")
                val content = if (f?.exists() == true) f.readText() else "No entries yet."
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("Saved text")
                    .setMessage(content)
                    .setPositiveButton("Close", null)
                    .show()
            }
        })
        setContentView(box)
    }
}
