package com.saveass.keyboard

import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SaveAssImeService : InputMethodService() {
    private var shift = false
    private var arabic = false

    private val englishRows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val arabicRows = listOf("ضصثقفغعهخحج", "شسيبلاتنمك", "ئءؤرلاىةوزظد")

    private fun isSensitiveField(info: EditorInfo?): Boolean {
        if (info == null) return true
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        val klass = info.inputType and InputType.TYPE_MASK_CLASS
        val password = variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            (klass == InputType.TYPE_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        val privateField = info.privateImeOptions?.contains("noPersonalizedLearning", ignoreCase = true) == true
        return password || privateField
    }

    private fun appendLog(text: String) {
        if (text.isEmpty() || isSensitiveField(currentInputEditorInfo)) return
        try {
            val file = File(getExternalFilesDir(null), "save ass.txt")
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            val app = currentInputEditorInfo?.packageName ?: "unknown"
            file.appendText("[$stamp] [$app] $text\n")
        } catch (_: Exception) { }
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 6, 4, 6)
            setBackgroundColor(Color.rgb(225, 230, 238))
        }
        root.addView(TextView(this).apply {
            text = "Save Ass • سجل محلي • حقول كلمات المرور مستثناة"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        })

        val languageRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        languageRow.addView(key(if (arabic) "العربية" else "English") {
            arabic = !arabic
            setInputView(onCreateInputView())
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(2, 2, 2, 2) })
        languageRow.addView(key("123 / ؟!") {
            currentInputConnection?.commitText(if (arabic) "،" else ",", 1)
            appendLog(if (arabic) "،" else ",")
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { setMargins(2, 2, 2, 2) })
        root.addView(languageRow)

        val rows = if (arabic) arabicRows else englishRows
        rows.forEachIndexed { index, row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            if (index == 1) line.setPadding(8, 0, 8, 0)
            row.forEach { ch ->
                line.addView(key(if (shift && !arabic) ch.uppercaseChar().toString() else ch.toString()) {
                    val value = if (shift && !arabic) ch.uppercaseChar() else ch
                    currentInputConnection?.commitText(value.toString(), 1)
                    appendLog(value.toString())
                    shift = false
                }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(2, 3, 2, 3) })
            }
            root.addView(line)
        }

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(key("⇧") { shift = !shift }, weight())
        controls.addView(key("⌫") {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }, weight())
        controls.addView(key("مسافة") {
            currentInputConnection?.commitText(" ", 1)
            appendLog(" ")
        }, LinearLayout.LayoutParams(0, dp(46), 2.5f).apply { setMargins(2, 3, 2, 3) })
        controls.addView(key("↵") {
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }, weight())
        root.addView(controls)
        return root
    }

    private fun weight() = LinearLayout.LayoutParams(0, dp(46), 1f).apply {
        setMargins(2, 3, 2, 3)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun key(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 14f
        isAllCaps = false
        setPadding(0, 0, 0, 0)
        setOnClickListener { action() }
    }
}
