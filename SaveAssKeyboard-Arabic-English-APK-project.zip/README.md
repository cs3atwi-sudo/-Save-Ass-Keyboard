# Save Ass Keyboard

Starter Android keyboard project with English and Arabic layouts.

## Features
- Switch between English QWERTY and an Arabic letter layout.
- Inserts typed characters into the active text field.
- Saves text typed through this keyboard locally with timestamp and app package.
- Skips standard Android password input types and fields marked `noPersonalizedLearning`.
- No network permission and no transmission of text.

## Storage
The log is stored as `save ass.txt` in the app-specific external files directory. Android scoped-storage restrictions mean it is not directly written to the public `Download` folder. Add an explicit user-controlled export via Android's Storage Access Framework to save a copy to Downloads.

## Build an APK
The repository includes `.github/workflows/build.yml`. Push this folder to a GitHub repository and run **Actions → Build Save Ass APK**. Download the `Save-Ass-debug-apk` artifact after the workflow succeeds.

## Limitations
This is an early prototype, not a production-ready keyboard. It has a basic letter layout and needs number/symbol pages, suggestions, RTL polishing, a proper log viewer/export screen, and broader testing. Android apps may mislabel sensitive fields; do not use it for passwords, banking, payment, or confidential information.
